import read #importing the dataset reading file
import sys




##Analysis

#1.Display all the list of companies of particular branch since five years?



def Companies_of_branch(branch):
	sample1=read.sheet2[read.sheet2.Branch==branch] #reading the 'particular' branch column
	samp1=sample1.Company.unique() #campany list
	
	s=[]
	for i in samp1: #for loop for unique list of companies
		if i not in s:
			s.append(i)
	for i in s:
		print("list of companies")
		print(i)

if __name__=='__main__':
	Companies_of_branch(sys.argv[1])
