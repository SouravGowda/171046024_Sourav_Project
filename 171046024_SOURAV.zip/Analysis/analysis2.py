import read #importing the dataset reading file


##Analysis

#2.List out all the students who got placed in particular 'branch' in VLSI  2015

def Placed_vlsi(company):
	sample2=read.sheet2[read.sheet2.Branch=='VLSI'] #for VLSI branch
	sam2=sample2[read.sheet2.Company==company] #moving to particular branch
	sam3=sam2[read.sheet2.Year==2015] #for particular year
	print("List of all Placed students")
	print(sam3)

if __name__=='__main__':
	Placed_vlsi(sys.argv[1])
