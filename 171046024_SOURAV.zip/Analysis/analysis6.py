import read #importing the dataset reading file

##Analysis

#6.What is the Percentage of students got placed in particular 'branch' in 2016

def percentage_of_branch(branch):
	sample6=read.sheet1[read.sheet1.Year==2016] #for year 2016
	samp6=sample6[read.sheet1.MscTechProgram==branch] #for particular branch
	sam=samp6.Percentage #percentage
	print("Percentage of students got placed in Embedded Systems in 2016 is:")
	print(sam) #display


if __name__=='__main__':
	percentage_of_branch(sys.argv[1])
