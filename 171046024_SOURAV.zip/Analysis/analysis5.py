import read #importing the dataset reading file

##Analysis

#5.How many number of students are ESIGELEC in the year 2014


def ESIGELEC_2014():
	sample5=read.sheet2[read.sheet2.Year==2014] #for 2014 year
	sam5=sample5[read.sheet2.Company=='ESIGELEC'] #company name given has 'ESIGELEC'
	print("Number of students are ESIGELEC in the year 2014")
	print(sam5.Company.count()) #display

if __name__=='__main__':
	ESIGELEC_2014()
