import read #importing the dataset reading file

##Analysis

#8.Display all companies that are attending SOIS department on particular year

def all_companies(year):
	sample8=read.sheet2[read.sheet2.Year==year] #for particular year
	samp8=sample8.Company.unique() #company list
	
	s=[]
	for i in samp8: #loop for no repeatation 
		if i not in s:
			s.append(i)
	for i in s:
		print(i)

	

if __name__=='__main__':
	all_companies(sys.argv[1])
