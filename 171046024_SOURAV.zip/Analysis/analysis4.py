import read #importing the dataset reading file

##Analysis



#4.List out all the students B.E aggregrate  who hired by  particular 'company' in 2012 batch

def BE_Aggregate(company):
	sample4=read.sheet2[read.sheet2.Year==2012] #for 2012 year
	samp4=sample4[read.sheet2.Company==company] #company name
	sam4=samp4.BE_Aggregate #for BE aggregate
	print("list of BE_Aggregate")
	print(sam4) #display BE aggregate

if __name__=='__main__':
	BE_Aggregate(sys.argv[1])
