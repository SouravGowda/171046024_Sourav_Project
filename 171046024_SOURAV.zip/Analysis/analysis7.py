import read #importing the dataset reading file

##Analysis

#7.What is the percentage of placement in all branches ""without ESIGELEC"" in 2015

def percentage_without_ESIGELEC():
	sample7=read.sheet1[read.sheet1.Year==2015] #for year 2015
	samp7=sample7[read.sheet1.MscTechProgram=='All branch without ESIGELEC'] #for branch without ESIGELEC
	sam=samp7.Percentage 
	print("percentage of placement in all branches without ESIGELEC in 2015 is:")
	print(sam) #printing percentage

if __name__=='__main__':
	percentage_without_ESIGELEC()
