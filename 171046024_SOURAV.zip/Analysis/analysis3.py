import read #importing the dataset reading file

##Analysis



#3.List out all the student required details of Bigdata-2016(Only required columns)


def All_Bigdata():
	sample3=read.sheet2[read.sheet2.Year==2016] #for particular year
	sam3=sample3[read.sheet2.Branch=='BDA'][['BE (BRANCH)','BE_Aggregate','I Sem GPA','Company','Stipend']]#only required columns
	print("All details of BDA-2016")	
	print(sam3)


if __name__=='__main__':
	All_Bigdata()
