import pandas as pd #to read a dataset

#import numpy as np #for numerical calculations in python

#import matplotlib.pyplot as plt #for plotting 

import sys

#### read excel sheet

sheet1= pd.read_excel('Placementsois.xlsx',sheetname='placementstats') #first sheet


sheet2= pd.read_excel('Placementsois.xlsx',sheetname='enrollment') #second sheet


sheet1_reindexing=sheet1.reset_index()
